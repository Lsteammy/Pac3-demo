
player_manager.AddValidModel( "Outside Chief", "models/vodoroda/chef/chief.mdl" )
